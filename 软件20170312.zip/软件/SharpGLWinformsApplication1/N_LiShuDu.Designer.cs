﻿namespace SharpGLWinformsApplication1
{
    partial class N_LiShuDu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(N_LiShuDu));
            this.skinMenuStrip1 = new CCWin.SkinControl.SkinMenuStrip();
            this.应力值ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.震动ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.形变量ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.裂纹形位ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.材料参数ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.涂层烧蚀量ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.传动阻力ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.电机扭矩ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.制动力矩ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.液压及电控ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.T0 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T1 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T2 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T3 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T4 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T5 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T6 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T7 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T8 = new CCWin.SkinControl.SkinWaterTextBox();
            this.T9 = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinPictureBox9 = new CCWin.SkinControl.SkinPictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.skinButton2_save = new CCWin.SkinControl.SkinButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.skinButton1 = new CCWin.SkinControl.SkinButton();
            this.skinMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox9)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // skinMenuStrip1
            // 
            this.skinMenuStrip1.Arrow = System.Drawing.Color.Black;
            this.skinMenuStrip1.Back = System.Drawing.Color.White;
            this.skinMenuStrip1.BackRadius = 4;
            this.skinMenuStrip1.BackRectangle = new System.Drawing.Rectangle(10, 10, 10, 10);
            this.skinMenuStrip1.Base = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(200)))), ((int)(((byte)(254)))));
            this.skinMenuStrip1.BaseFore = System.Drawing.Color.Black;
            this.skinMenuStrip1.BaseForeAnamorphosis = false;
            this.skinMenuStrip1.BaseForeAnamorphosisBorder = 4;
            this.skinMenuStrip1.BaseForeAnamorphosisColor = System.Drawing.Color.White;
            this.skinMenuStrip1.BaseHoverFore = System.Drawing.Color.White;
            this.skinMenuStrip1.BaseItemAnamorphosis = true;
            this.skinMenuStrip1.BaseItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinMenuStrip1.BaseItemBorderShow = true;
            this.skinMenuStrip1.BaseItemDown = ((System.Drawing.Image)(resources.GetObject("skinMenuStrip1.BaseItemDown")));
            this.skinMenuStrip1.BaseItemHover = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinMenuStrip1.BaseItemMouse = ((System.Drawing.Image)(resources.GetObject("skinMenuStrip1.BaseItemMouse")));
            this.skinMenuStrip1.BaseItemPressed = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinMenuStrip1.BaseItemRadius = 4;
            this.skinMenuStrip1.BaseItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinMenuStrip1.BaseItemSplitter = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.skinMenuStrip1.DropDownImageSeparator = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(197)))), ((int)(((byte)(197)))));
            this.skinMenuStrip1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinMenuStrip1.Fore = System.Drawing.Color.Black;
            this.skinMenuStrip1.HoverFore = System.Drawing.Color.White;
            this.skinMenuStrip1.ItemAnamorphosis = true;
            this.skinMenuStrip1.ItemBorder = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(148)))), ((int)(((byte)(212)))));
            this.skinMenuStrip1.ItemBorderShow = true;
            this.skinMenuStrip1.ItemHover = System.Drawing.Color.Transparent;
            this.skinMenuStrip1.ItemPressed = System.Drawing.Color.Transparent;
            this.skinMenuStrip1.ItemRadius = 4;
            this.skinMenuStrip1.ItemRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.应力值ToolStripMenuItem,
            this.震动ToolStripMenuItem,
            this.形变量ToolStripMenuItem,
            this.裂纹形位ToolStripMenuItem,
            this.材料参数ToolStripMenuItem,
            this.涂层烧蚀量ToolStripMenuItem,
            this.传动阻力ToolStripMenuItem,
            this.电机扭矩ToolStripMenuItem,
            this.制动力矩ToolStripMenuItem,
            this.液压及电控ToolStripMenuItem});
            this.skinMenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.skinMenuStrip1.Name = "skinMenuStrip1";
            this.skinMenuStrip1.Padding = new System.Windows.Forms.Padding(3, 2, 0, 2);
            this.skinMenuStrip1.RadiusStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinMenuStrip1.Size = new System.Drawing.Size(761, 28);
            this.skinMenuStrip1.SkinAllColor = true;
            this.skinMenuStrip1.TabIndex = 1;
            this.skinMenuStrip1.Text = "skinMenuStrip1";
            this.skinMenuStrip1.TitleAnamorphosis = true;
            this.skinMenuStrip1.TitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(228)))), ((int)(((byte)(236)))));
            this.skinMenuStrip1.TitleRadius = 4;
            this.skinMenuStrip1.TitleRadiusStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // 应力值ToolStripMenuItem
            // 
            this.应力值ToolStripMenuItem.Name = "应力值ToolStripMenuItem";
            this.应力值ToolStripMenuItem.Size = new System.Drawing.Size(63, 24);
            this.应力值ToolStripMenuItem.Text = "应力值";
            this.应力值ToolStripMenuItem.Click += new System.EventHandler(this.应力值ToolStripMenuItem_Click);
            // 
            // 震动ToolStripMenuItem
            // 
            this.震动ToolStripMenuItem.Name = "震动ToolStripMenuItem";
            this.震动ToolStripMenuItem.Size = new System.Drawing.Size(63, 24);
            this.震动ToolStripMenuItem.Text = "振动量";
            this.震动ToolStripMenuItem.Click += new System.EventHandler(this.震动ToolStripMenuItem_Click);
            // 
            // 形变量ToolStripMenuItem
            // 
            this.形变量ToolStripMenuItem.Name = "形变量ToolStripMenuItem";
            this.形变量ToolStripMenuItem.Size = new System.Drawing.Size(63, 24);
            this.形变量ToolStripMenuItem.Text = "形变量";
            this.形变量ToolStripMenuItem.Click += new System.EventHandler(this.形变量ToolStripMenuItem_Click);
            // 
            // 裂纹形位ToolStripMenuItem
            // 
            this.裂纹形位ToolStripMenuItem.Name = "裂纹形位ToolStripMenuItem";
            this.裂纹形位ToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.裂纹形位ToolStripMenuItem.Text = "裂纹形位";
            this.裂纹形位ToolStripMenuItem.Click += new System.EventHandler(this.裂纹形位ToolStripMenuItem_Click);
            // 
            // 材料参数ToolStripMenuItem
            // 
            this.材料参数ToolStripMenuItem.Name = "材料参数ToolStripMenuItem";
            this.材料参数ToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.材料参数ToolStripMenuItem.Text = "材料参数";
            this.材料参数ToolStripMenuItem.Click += new System.EventHandler(this.材料参数ToolStripMenuItem_Click);
            // 
            // 涂层烧蚀量ToolStripMenuItem
            // 
            this.涂层烧蚀量ToolStripMenuItem.Name = "涂层烧蚀量ToolStripMenuItem";
            this.涂层烧蚀量ToolStripMenuItem.Size = new System.Drawing.Size(91, 24);
            this.涂层烧蚀量ToolStripMenuItem.Text = "涂层烧蚀量";
            this.涂层烧蚀量ToolStripMenuItem.Click += new System.EventHandler(this.涂层烧蚀量ToolStripMenuItem_Click);
            // 
            // 传动阻力ToolStripMenuItem
            // 
            this.传动阻力ToolStripMenuItem.Name = "传动阻力ToolStripMenuItem";
            this.传动阻力ToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.传动阻力ToolStripMenuItem.Text = "传动阻力";
            this.传动阻力ToolStripMenuItem.Click += new System.EventHandler(this.传动阻力ToolStripMenuItem_Click);
            // 
            // 电机扭矩ToolStripMenuItem
            // 
            this.电机扭矩ToolStripMenuItem.Name = "电机扭矩ToolStripMenuItem";
            this.电机扭矩ToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.电机扭矩ToolStripMenuItem.Text = "电机扭矩";
            this.电机扭矩ToolStripMenuItem.Click += new System.EventHandler(this.电机扭矩ToolStripMenuItem_Click);
            // 
            // 制动力矩ToolStripMenuItem
            // 
            this.制动力矩ToolStripMenuItem.Name = "制动力矩ToolStripMenuItem";
            this.制动力矩ToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.制动力矩ToolStripMenuItem.Text = "制动力矩";
            this.制动力矩ToolStripMenuItem.Click += new System.EventHandler(this.制动力矩ToolStripMenuItem_Click);
            // 
            // 液压及电控ToolStripMenuItem
            // 
            this.液压及电控ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.液压及电控ToolStripMenuItem.Name = "液压及电控ToolStripMenuItem";
            this.液压及电控ToolStripMenuItem.Size = new System.Drawing.Size(91, 24);
            this.液压及电控ToolStripMenuItem.Text = "液压及电控";
            this.液压及电控ToolStripMenuItem.Click += new System.EventHandler(this.液压及电控ToolStripMenuItem_Click);
            // 
            // T0
            // 
            this.T0.Location = new System.Drawing.Point(437, 354);
            this.T0.Name = "T0";
            this.T0.Size = new System.Drawing.Size(107, 26);
            this.T0.TabIndex = 3;
            this.T0.Text = "0";
            this.T0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T0.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T0.WaterText = "";
            // 
            // T1
            // 
            this.T1.Location = new System.Drawing.Point(296, 354);
            this.T1.Name = "T1";
            this.T1.Size = new System.Drawing.Size(107, 26);
            this.T1.TabIndex = 4;
            this.T1.Text = "20";
            this.T1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T1.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T1.WaterText = "";
            // 
            // T2
            // 
            this.T2.Location = new System.Drawing.Point(437, 290);
            this.T2.Name = "T2";
            this.T2.ReadOnly = true;
            this.T2.Size = new System.Drawing.Size(107, 26);
            this.T2.TabIndex = 5;
            this.T2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T2.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T2.WaterText = "";
            // 
            // T3
            // 
            this.T3.Location = new System.Drawing.Point(296, 290);
            this.T3.Name = "T3";
            this.T3.Size = new System.Drawing.Size(107, 26);
            this.T3.TabIndex = 6;
            this.T3.Text = "40";
            this.T3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T3.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T3.WaterText = "";
            // 
            // T4
            // 
            this.T4.Location = new System.Drawing.Point(437, 228);
            this.T4.Name = "T4";
            this.T4.ReadOnly = true;
            this.T4.Size = new System.Drawing.Size(107, 26);
            this.T4.TabIndex = 7;
            this.T4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T4.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T4.WaterText = "";
            // 
            // T5
            // 
            this.T5.Location = new System.Drawing.Point(296, 228);
            this.T5.Name = "T5";
            this.T5.Size = new System.Drawing.Size(107, 26);
            this.T5.TabIndex = 8;
            this.T5.Text = "60";
            this.T5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T5.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T5.WaterText = "";
            // 
            // T6
            // 
            this.T6.Location = new System.Drawing.Point(437, 160);
            this.T6.Name = "T6";
            this.T6.ReadOnly = true;
            this.T6.Size = new System.Drawing.Size(107, 26);
            this.T6.TabIndex = 9;
            this.T6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T6.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T6.WaterText = "";
            // 
            // T7
            // 
            this.T7.Location = new System.Drawing.Point(296, 160);
            this.T7.Name = "T7";
            this.T7.Size = new System.Drawing.Size(107, 26);
            this.T7.TabIndex = 10;
            this.T7.Text = "80";
            this.T7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T7.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T7.WaterText = "";
            // 
            // T8
            // 
            this.T8.Location = new System.Drawing.Point(437, 91);
            this.T8.Name = "T8";
            this.T8.ReadOnly = true;
            this.T8.Size = new System.Drawing.Size(107, 26);
            this.T8.TabIndex = 11;
            this.T8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T8.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T8.WaterText = "";
            // 
            // T9
            // 
            this.T9.Location = new System.Drawing.Point(296, 91);
            this.T9.Name = "T9";
            this.T9.Size = new System.Drawing.Size(107, 26);
            this.T9.TabIndex = 12;
            this.T9.Text = "100";
            this.T9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T9.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.T9.WaterText = "";
            // 
            // skinPictureBox9
            // 
            this.skinPictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.skinPictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("skinPictureBox9.Image")));
            this.skinPictureBox9.Location = new System.Drawing.Point(54, 25);
            this.skinPictureBox9.Name = "skinPictureBox9";
            this.skinPictureBox9.Size = new System.Drawing.Size(645, 379);
            this.skinPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.skinPictureBox9.TabIndex = 2;
            this.skinPictureBox9.TabStop = false;
            this.skinPictureBox9.Click += new System.EventHandler(this.skinPictureBox9_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.skinButton2_save);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.skinButton1);
            this.groupBox1.Controls.Add(this.T0);
            this.groupBox1.Controls.Add(this.T3);
            this.groupBox1.Controls.Add(this.T1);
            this.groupBox1.Controls.Add(this.T9);
            this.groupBox1.Controls.Add(this.T2);
            this.groupBox1.Controls.Add(this.T8);
            this.groupBox1.Controls.Add(this.T7);
            this.groupBox1.Controls.Add(this.T4);
            this.groupBox1.Controls.Add(this.T6);
            this.groupBox1.Controls.Add(this.T5);
            this.groupBox1.Controls.Add(this.skinPictureBox9);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox1.Location = new System.Drawing.Point(0, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(761, 432);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "1";
            // 
            // skinButton2_save
            // 
            this.skinButton2_save.BackColor = System.Drawing.Color.Transparent;
            this.skinButton2_save.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton2_save.DownBack = null;
            this.skinButton2_save.Location = new System.Drawing.Point(702, 152);
            this.skinButton2_save.MouseBack = null;
            this.skinButton2_save.Name = "skinButton2_save";
            this.skinButton2_save.NormlBack = null;
            this.skinButton2_save.Size = new System.Drawing.Size(55, 39);
            this.skinButton2_save.TabIndex = 16;
            this.skinButton2_save.Text = "保存";
            this.skinButton2_save.UseVisualStyleBackColor = false;
            this.skinButton2_save.Click += new System.EventHandler(this.skinButton2_save_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(34, 192);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(216, 95);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.Visible = false;
            // 
            // skinButton1
            // 
            this.skinButton1.BackColor = System.Drawing.Color.Transparent;
            this.skinButton1.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton1.DownBack = null;
            this.skinButton1.Location = new System.Drawing.Point(702, 248);
            this.skinButton1.MouseBack = null;
            this.skinButton1.Name = "skinButton1";
            this.skinButton1.NormlBack = null;
            this.skinButton1.Size = new System.Drawing.Size(55, 39);
            this.skinButton1.TabIndex = 14;
            this.skinButton1.Text = "重置";
            this.skinButton1.UseVisualStyleBackColor = false;
            this.skinButton1.Click += new System.EventHandler(this.skinButton1_Click);
            // 
            // N_LiShuDu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 466);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.skinMenuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MainMenuStrip = this.skinMenuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "N_LiShuDu";
            this.Text = "N_LiShuDu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.N_LiShuDu_FormClosing);
            this.Load += new System.EventHandler(this.N_LiShuDu_Load);
            this.skinMenuStrip1.ResumeLayout(false);
            this.skinMenuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinPictureBox9)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CCWin.SkinControl.SkinMenuStrip skinMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 应力值ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 震动ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 形变量ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 裂纹形位ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 材料参数ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 涂层烧蚀量ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 传动阻力ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 电机扭矩ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 制动力矩ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 液压及电控ToolStripMenuItem;
        private CCWin.SkinControl.SkinWaterTextBox T0;
        private CCWin.SkinControl.SkinWaterTextBox T1;
        private CCWin.SkinControl.SkinWaterTextBox T2;
        private CCWin.SkinControl.SkinWaterTextBox T3;
        private CCWin.SkinControl.SkinWaterTextBox T4;
        private CCWin.SkinControl.SkinWaterTextBox T5;
        private CCWin.SkinControl.SkinWaterTextBox T6;
        private CCWin.SkinControl.SkinWaterTextBox T7;
        private CCWin.SkinControl.SkinWaterTextBox T8;
        private CCWin.SkinControl.SkinWaterTextBox T9;
        private CCWin.SkinControl.SkinPictureBox skinPictureBox9;
        private System.Windows.Forms.GroupBox groupBox1;
        private CCWin.SkinControl.SkinButton skinButton1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private CCWin.SkinControl.SkinButton skinButton2_save;

    }
}