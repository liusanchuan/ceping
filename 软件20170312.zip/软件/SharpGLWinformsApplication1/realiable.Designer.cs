﻿namespace SharpGLWinformsApplication1
{
    partial class realiable
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.labe1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label0 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.labe9 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.labe6 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.labe8 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.labe7 = new System.Windows.Forms.Label();
            this.labe2 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.labe3 = new System.Windows.Forms.Label();
            this.labe4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.labe5 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.YYJDK = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.ZDLJ = new System.Windows.Forms.TextBox();
            this.DJNJ = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.CDZL = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.CLCS = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.YLZ = new System.Windows.Forms.TextBox();
            this.LWXW = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SSL = new System.Windows.Forms.TextBox();
            this.ZDL = new System.Windows.Forms.TextBox();
            this.XBL = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labelmatrix = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // labe1
            // 
            this.labe1.AutoSize = true;
            this.labe1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.labe1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe1.Location = new System.Drawing.Point(10, 470);
            this.labe1.Name = "labe1";
            this.labe1.Size = new System.Drawing.Size(123, 19);
            this.labe1.TabIndex = 25;
            this.labe1.Text = "液压及电控：";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox1.Location = new System.Drawing.Point(120, 40);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(90, 22);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox10.Location = new System.Drawing.Point(120, 472);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(90, 22);
            this.textBox10.TabIndex = 24;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label0
            // 
            this.label0.AutoSize = true;
            this.label0.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label0.Location = new System.Drawing.Point(10, 426);
            this.label0.Name = "label0";
            this.label0.Size = new System.Drawing.Size(104, 19);
            this.label0.TabIndex = 23;
            this.label0.Text = "制动力矩：";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox9.Location = new System.Drawing.Point(120, 432);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(90, 22);
            this.textBox9.TabIndex = 22;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labe9
            // 
            this.labe9.AutoSize = true;
            this.labe9.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe9.Location = new System.Drawing.Point(10, 383);
            this.labe9.Name = "labe9";
            this.labe9.Size = new System.Drawing.Size(104, 19);
            this.labe9.TabIndex = 21;
            this.labe9.Text = "电机扭矩：";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox8.Location = new System.Drawing.Point(120, 383);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(90, 22);
            this.textBox8.TabIndex = 20;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labe6
            // 
            this.labe6.AutoSize = true;
            this.labe6.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe6.Location = new System.Drawing.Point(10, 236);
            this.labe6.Name = "labe6";
            this.labe6.Size = new System.Drawing.Size(104, 19);
            this.labe6.TabIndex = 19;
            this.labe6.Text = "材料参数：";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox7.Location = new System.Drawing.Point(120, 334);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(90, 22);
            this.textBox7.TabIndex = 18;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labe8
            // 
            this.labe8.AutoSize = true;
            this.labe8.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe8.Location = new System.Drawing.Point(10, 337);
            this.labe8.Name = "labe8";
            this.labe8.Size = new System.Drawing.Size(104, 19);
            this.labe8.TabIndex = 13;
            this.labe8.Text = "传动阻力：";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(20, 237);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(153, 50);
            this.button4.TabIndex = 35;
            this.button4.Text = "更改隶属度指标";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox5.Location = new System.Drawing.Point(120, 236);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(90, 22);
            this.textBox5.TabIndex = 14;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox6.Location = new System.Drawing.Point(120, 285);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(90, 22);
            this.textBox6.TabIndex = 16;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labe7
            // 
            this.labe7.AutoSize = true;
            this.labe7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.labe7.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe7.Location = new System.Drawing.Point(10, 288);
            this.labe7.Name = "labe7";
            this.labe7.Size = new System.Drawing.Size(123, 19);
            this.labe7.TabIndex = 17;
            this.labe7.Text = "涂层烧蚀量：";
            // 
            // labe2
            // 
            this.labe2.AutoSize = true;
            this.labe2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.labe2.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe2.Location = new System.Drawing.Point(10, 43);
            this.labe2.Name = "labe2";
            this.labe2.Size = new System.Drawing.Size(66, 19);
            this.labe2.TabIndex = 1;
            this.labe2.Text = "应力：";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox4.Location = new System.Drawing.Point(120, 187);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(90, 22);
            this.textBox4.TabIndex = 12;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox2.Location = new System.Drawing.Point(120, 89);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(90, 22);
            this.textBox2.TabIndex = 2;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labe3
            // 
            this.labe3.AutoSize = true;
            this.labe3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe3.Location = new System.Drawing.Point(10, 89);
            this.labe3.Name = "labe3";
            this.labe3.Size = new System.Drawing.Size(66, 19);
            this.labe3.TabIndex = 3;
            this.labe3.Text = "振动：";
            // 
            // labe4
            // 
            this.labe4.AutoSize = true;
            this.labe4.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe4.Location = new System.Drawing.Point(10, 138);
            this.labe4.Name = "labe4";
            this.labe4.Size = new System.Drawing.Size(66, 19);
            this.labe4.TabIndex = 5;
            this.labe4.Text = "形变：";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(20, 154);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(153, 50);
            this.button3.TabIndex = 34;
            this.button3.Text = "判断矩阵";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // labe5
            // 
            this.labe5.AutoSize = true;
            this.labe5.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labe5.Location = new System.Drawing.Point(10, 187);
            this.labe5.Name = "labe5";
            this.labe5.Size = new System.Drawing.Size(66, 19);
            this.labe5.TabIndex = 15;
            this.labe5.Text = "裂纹：";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.ForeColor = System.Drawing.Color.Red;
            this.button5.Location = new System.Drawing.Point(20, 71);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(153, 50);
            this.button5.TabIndex = 36;
            this.button5.Text = "开始评估";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_2);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox3.Controls.Add(this.labe1);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.label0);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.labe9);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.labe6);
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.labe8);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.labe5);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.labe7);
            this.groupBox3.Controls.Add(this.labe2);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.labe3);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.labe4);
            this.groupBox3.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox3.Location = new System.Drawing.Point(22, 36);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(273, 528);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "指标权重";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("宋体", 14.25F);
            this.textBox3.Location = new System.Drawing.Point(120, 138);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(90, 22);
            this.textBox3.TabIndex = 4;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(20, 320);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 50);
            this.button2.TabIndex = 30;
            this.button2.Text = "输入重置";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // YYJDK
            // 
            this.YYJDK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.YYJDK.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.YYJDK.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.YYJDK.Location = new System.Drawing.Point(139, 475);
            this.YYJDK.Name = "YYJDK";
            this.YYJDK.Size = new System.Drawing.Size(90, 29);
            this.YYJDK.TabIndex = 30;
            this.YYJDK.Text = "68";
            this.YYJDK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(12, 480);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(123, 19);
            this.label22.TabIndex = 29;
            this.label22.Text = "液压及电控：";
            // 
            // ZDLJ
            // 
            this.ZDLJ.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ZDLJ.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ZDLJ.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ZDLJ.Location = new System.Drawing.Point(139, 429);
            this.ZDLJ.Name = "ZDLJ";
            this.ZDLJ.Size = new System.Drawing.Size(90, 29);
            this.ZDLJ.TabIndex = 28;
            this.ZDLJ.Text = "32";
            this.ZDLJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DJNJ
            // 
            this.DJNJ.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DJNJ.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.DJNJ.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DJNJ.Location = new System.Drawing.Point(139, 380);
            this.DJNJ.Name = "DJNJ";
            this.DJNJ.Size = new System.Drawing.Size(90, 29);
            this.DJNJ.TabIndex = 27;
            this.DJNJ.Text = "80";
            this.DJNJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(12, 434);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 19);
            this.label18.TabIndex = 26;
            this.label18.Text = "制动力矩：";
            // 
            // CDZL
            // 
            this.CDZL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CDZL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.CDZL.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CDZL.Location = new System.Drawing.Point(139, 331);
            this.CDZL.Name = "CDZL";
            this.CDZL.Size = new System.Drawing.Size(90, 29);
            this.CDZL.TabIndex = 18;
            this.CDZL.Text = "50";
            this.CDZL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(12, 385);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(104, 19);
            this.label19.TabIndex = 25;
            this.label19.Text = "电机扭矩：";
            // 
            // CLCS
            // 
            this.CLCS.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CLCS.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.CLCS.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CLCS.Location = new System.Drawing.Point(139, 233);
            this.CLCS.Name = "CLCS";
            this.CLCS.Size = new System.Drawing.Size(90, 29);
            this.CLCS.TabIndex = 14;
            this.CLCS.Text = "99";
            this.CLCS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(12, 336);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 19);
            this.label9.TabIndex = 19;
            this.label9.Text = "传动阻力：";
            // 
            // YLZ
            // 
            this.YLZ.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.YLZ.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.YLZ.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.YLZ.Location = new System.Drawing.Point(139, 37);
            this.YLZ.Name = "YLZ";
            this.YLZ.Size = new System.Drawing.Size(90, 29);
            this.YLZ.TabIndex = 0;
            this.YLZ.Text = "81";
            this.YLZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LWXW
            // 
            this.LWXW.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.LWXW.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.LWXW.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LWXW.Location = new System.Drawing.Point(139, 184);
            this.LWXW.Name = "LWXW";
            this.LWXW.Size = new System.Drawing.Size(90, 29);
            this.LWXW.TabIndex = 12;
            this.LWXW.Text = "85";
            this.LWXW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(12, 238);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 19);
            this.label10.TabIndex = 15;
            this.label10.Text = "材料参数：";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox1.Controls.Add(this.button14);
            this.groupBox1.Controls.Add(this.button13);
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(this.button11);
            this.groupBox1.Controls.Add(this.button10);
            this.groupBox1.Controls.Add(this.button9);
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.YYJDK);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.ZDLJ);
            this.groupBox1.Controls.Add(this.DJNJ);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.CDZL);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.CLCS);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.SSL);
            this.groupBox1.Controls.Add(this.YLZ);
            this.groupBox1.Controls.Add(this.LWXW);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.ZDL);
            this.groupBox1.Controls.Add(this.XBL);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox1.Location = new System.Drawing.Point(312, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(298, 528);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "输入待评估值";
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.Location = new System.Drawing.Point(235, 478);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(42, 28);
            this.button14.TabIndex = 50;
            this.button14.Text = "查看";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.Location = new System.Drawing.Point(235, 430);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(42, 28);
            this.button13.TabIndex = 49;
            this.button13.Text = "查看";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button12.Location = new System.Drawing.Point(235, 383);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(42, 28);
            this.button12.TabIndex = 48;
            this.button12.Text = "查看";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button11.Location = new System.Drawing.Point(235, 334);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(42, 28);
            this.button11.TabIndex = 47;
            this.button11.Text = "查看";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.Location = new System.Drawing.Point(235, 285);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(42, 28);
            this.button10.TabIndex = 46;
            this.button10.Text = "查看";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button9.Location = new System.Drawing.Point(235, 235);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(42, 28);
            this.button9.TabIndex = 45;
            this.button9.Text = "查看";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button8.Location = new System.Drawing.Point(235, 186);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(42, 28);
            this.button8.TabIndex = 44;
            this.button8.Text = "查看";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button7.Location = new System.Drawing.Point(235, 137);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(42, 28);
            this.button7.TabIndex = 43;
            this.button7.Text = "查看";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.Location = new System.Drawing.Point(235, 88);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(42, 28);
            this.button6.TabIndex = 42;
            this.button6.Text = "查看";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(235, 38);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(42, 28);
            this.button1.TabIndex = 41;
            this.button1.Text = "查看";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SSL
            // 
            this.SSL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.SSL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.SSL.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SSL.Location = new System.Drawing.Point(139, 282);
            this.SSL.Name = "SSL";
            this.SSL.Size = new System.Drawing.Size(90, 29);
            this.SSL.TabIndex = 16;
            this.SSL.Text = "18";
            this.SSL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ZDL
            // 
            this.ZDL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ZDL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ZDL.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ZDL.Location = new System.Drawing.Point(139, 86);
            this.ZDL.Name = "ZDL";
            this.ZDL.Size = new System.Drawing.Size(90, 29);
            this.ZDL.TabIndex = 2;
            this.ZDL.Text = "99";
            this.ZDL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // XBL
            // 
            this.XBL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.XBL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.XBL.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.XBL.Location = new System.Drawing.Point(139, 135);
            this.XBL.Name = "XBL";
            this.XBL.Size = new System.Drawing.Size(90, 29);
            this.XBL.TabIndex = 4;
            this.XBL.Text = "56";
            this.XBL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(12, 287);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(123, 19);
            this.label11.TabIndex = 17;
            this.label11.Text = "涂层烧蚀量：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label12.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(12, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 19);
            this.label12.TabIndex = 1;
            this.label12.Text = "应力值：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(12, 140);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 19);
            this.label15.TabIndex = 5;
            this.label15.Text = "形变量：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(12, 189);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 19);
            this.label13.TabIndex = 13;
            this.label13.Text = "裂纹形位：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(12, 91);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 19);
            this.label14.TabIndex = 3;
            this.label14.Text = "振动量：";
            // 
            // labelmatrix
            // 
            this.labelmatrix.AutoSize = true;
            this.labelmatrix.BackColor = System.Drawing.Color.DarkRed;
            this.labelmatrix.Location = new System.Drawing.Point(301, 36);
            this.labelmatrix.Name = "labelmatrix";
            this.labelmatrix.Size = new System.Drawing.Size(11, 12);
            this.labelmatrix.TabIndex = 37;
            this.labelmatrix.Text = ":";
            this.labelmatrix.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteCustomSource.AddRange(new string[] {
            "400"});
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 16;
            this.comboBox1.Items.AddRange(new object[] {
            "400",
            "800"});
            this.comboBox1.Location = new System.Drawing.Point(101, 430);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(72, 24);
            this.comboBox1.Sorted = true;
            this.comboBox1.TabIndex = 39;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(21, 430);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 21);
            this.label1.TabIndex = 40;
            this.label1.Text = "源头载荷:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(628, 36);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(182, 528);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "设置参数";
            // 
            // realiable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.labelmatrix);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.DoubleBuffered = true;
            this.Location = new System.Drawing.Point(10, 10);
            this.Name = "realiable";
            this.Size = new System.Drawing.Size(830, 640);
            this.Load += new System.EventHandler(this.realiable_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labe1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label0;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label labe9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label labe6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label labe8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label labe7;
        private System.Windows.Forms.Label labe2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label labe3;
        private System.Windows.Forms.Label labe4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label labe5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox YYJDK;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox ZDLJ;
        private System.Windows.Forms.TextBox DJNJ;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox CDZL;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox CLCS;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox YLZ;
        private System.Windows.Forms.TextBox LWXW;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox SSL;
        private System.Windows.Forms.TextBox ZDL;
        private System.Windows.Forms.TextBox XBL;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelmatrix;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}
